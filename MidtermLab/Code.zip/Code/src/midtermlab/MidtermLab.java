/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midtermlab;

/**
 *
 * @author sp20-bse-072
 */
public class MidtermLab {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        LiveCricket cricket=new MansehraCricket();
        LiveCricket cricket2=new AliPoorCricket();
        LiveCricket cricket3=new AyubCricket();
        User user=new userA();
        
    }
    
}
